CREATE TABLE inventory (
   inventory_id INT PRIMARY KEY,
   product_id INT,
   quantity INT,
   FOREIGN KEY (product_id) REFERENCES product(product_id)
);

CREATE TABLE product (
   product_id INT PRIMARY KEY,
   product_name VARCHAR(255),
   unit_price DECIMAL(10,2),
   description VARCHAR(1000),
   company_id INT,
   FOREIGN KEY (company_id) REFERENCES company(company_id)
);

CREATE TABLE shipment (
   shipment_id INT PRIMARY KEY,
   product_id INT,
   quantity INT,
   shipment_date DATE,
   company_id INT,
   FOREIGN KEY (product_id) REFERENCES product(product_id),
   FOREIGN KEY (company_id) REFERENCES company(company_id)
);

CREATE TABLE orders (
   order_id INT PRIMARY KEY,
   product_id INT,
   quantity INT,
   order_date DATE,
   company_id INT,
   FOREIGN KEY (product_id) REFERENCES product(product_id),
   FOREIGN KEY (company_id) REFERENCES company(company_id)
);

CREATE TABLE company (
   company_id INT PRIMARY KEY,
   company_name VARCHAR(255),
   address VARCHAR(1000),
   phone_number VARCHAR(20),
   email VARCHAR(255)
);