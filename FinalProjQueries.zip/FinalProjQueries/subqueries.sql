
SELECT product_name
FROM product
WHERE product_id IN (
  SELECT product_id
  FROM orders
  WHERE unit_price > 10
);

SELECT product_id
FROM product
WHERE product_id IN (
  SELECT product_id
  FROM orders
  WHERE order_date >= DATEADD(month,-1, GETDATE())
);

SELECT product_name, unit_price
FROM product
WHERE unit_price >(
    SELECT AVG(unit_price)
    FROM product
)

SELECT product_name
FROM product
WHERE company_id IN (
    SELECT company_id
    FROM inventory
    WHERE company_id = 800
)