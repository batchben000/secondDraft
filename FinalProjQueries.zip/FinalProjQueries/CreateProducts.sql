INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (01, ' Laptop', 210.99, ' Portable Laptop Computer ', 000);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (02, ' Desktop', 510.99, ' Desktop Computer ', 000);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (03, ' Monitor', 50.99, ' Monitor for Desktop Computer ', 000);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (04, ' Keyboard', 30.99, ' Wireless Keyboard for Desktop Computer ', 000);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (05, ' Mouse', 210.99, ' Wireless Mouse for Desktop Computer ', 000);


INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (10, ' US Men 6', 69.99, ' US Men Size 6 Shoes', 200);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (20, ' US Men 7', 69.99, ' US Men Size 7 Shoes', 200);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (30, ' US Men 8', 69.99, ' US Men Size 8 Shoes', 200);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (40, ' US Men 9', 69.99, ' US Men Size 9 Shoes', 200);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (50, ' US Men 10', 69.99, ' US Men Size 10 Shoes', 200);


INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (11, ' Skim Milk', 3.99, ' Fat Free Dairy Milk ', 300);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (12, ' 1% Milk', 3.99, ' 1% Fat Dairy Milk ', 300);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (13, ' 2% Milk', 3.99, ' 2% Fat Dairy Milk ', 300);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (14, ' Whole Milk', 3.99, ' Full Fat Dairy Milk ', 300);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (15, ' Soy Milk', 3.99, ' Soy-Based Dairy Alternative ', 300);



INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (21, ' Espresso', 3.49, ' Espresso Shot ', 400);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (22, ' Flat White', 3.99, ' Espresso With Microfoamed Milk ', 400);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (23, ' Latte', 3.99, ' Espresso With Milk ', 400);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (24, ' Americano', 3.49, ' Espresso With Water ', 400);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (25, ' Frappe', 4.49, ' Blended Iced Espresso With Milk and Syrup ', 400);



INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (31, ' White Cow', 100.00, ' Healthy White Cow, Produces White Milk', 500);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (32, ' Brown Cow', 100.00, ' Healthy Brown Cow, Produces Chocolate Milk', 500);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (33, ' Black Cow', 100.00, ' Healthy Black Cow, Produces Truffle Oil ', 500);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (34, ' Red Cow', 200.00, ' Healthy Strawberry Cow, Produces Strawberry Milk', 500);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (35, ' Mooshroom Cow', 400.00, ' Healthy Mushroom Cow, Produces Mushroom Stew', 500);



INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (41, ' Rollerblades', 39.99, ' One Pair Rollerblades ', 600);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (42, ' Rollerskates', 29.99, ' One Pair Rollerskates ', 600);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (43, ' Skateboard', 69.99, ' Fully Assembled Skateboard ', 600);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (44, ' Longboard', 69.99, ' Fully Assembled Longboard ', 600);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (45, ' Pennyboard', 29.99, ' Fully Assembled Pennyboard ', 600);



INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (51, ' Snapback', 29.99, ' Adjustable Snapback Hat ', 700);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (52, ' Curved Baseball Cap', 29.99, ' Brimmed Baseball Cap, Nonadjustable ', 700);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (53, ' Flat Baseball Cap', 29.99, ' Flatbrimmed Baseball Cap, Nonadjustable ', 700);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (54, ' Stetson', 49.99, ' Stetson Western Cowboy Hat ', 700);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (55, ' Fedora', 29.99, ' Black Fedora ', 700);



INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (61, ' Dining Chair', 49.99, ' Wooden Dining Chair ', 800);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (62, ' Armchair', 69.99, ' Comfortable Living Armchair ', 800);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (63, ' Rocking Chair', 49.99, ' Wooden Rocking Chair With Cushion ', 800);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (64, ' Bench', 59.99, ' Wooden Dining Bench ', 800);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (65, ' Study Chair', 49.99, ' Wooden Desk Chair With Cushion ', 800);



INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (71, ' Succulent', 9.99, ' Healthy Succulent ', 900);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (72, ' Aloe Vera', 9.99, ' Healthy Aloe Vera Plant ', 900);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (73, ' Fiddle-Leaf Fig ', 19.99, ' Healthy Fiddle-Leaf Fig Plant ', 900);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (74, ' Monstera', 19.99, ' Healthy Monstera Plant ', 900);

INSERT INTO product (product_id, product_name, unit_price, description, company_id)
VALUES (75, ' Fan Palm', 19.99, ' Healthy Fan Palm Plant ', 900);