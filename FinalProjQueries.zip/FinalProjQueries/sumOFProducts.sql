SELECT SUM(unit_price) as total_sum
FROM product

SELECT MAX(unit_price) 
FROM product

SELECT AVG(unit_price) as averagePrice
FROM product