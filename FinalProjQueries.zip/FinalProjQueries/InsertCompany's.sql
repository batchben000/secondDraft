

INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (200, 'Cheapskates Shoestore', 'BigBlueTown 5421', 1548978941,'cheapskatesshoes@email');


INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (100, 'Custom Shirt Design', 'BigBrownTown 1245', 1234567891,'customshirtdesign@email');


INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (300, 'Milky Bois', 'BigYellowTown 4235', 123456745,'thosemilkybois@email');



INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (400, 'The Grind Coffee and Espresso', 'BigRedTown 2134', 1234127891,'thegrindcoffee@email');



INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (500, 'Dairy Bros.', 'BigMagentaTown 1243', 1234567221,'dairybros@email');



INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (600, 'Wheelz & Co.', 'BigPinkTown 3241', 4321567891,'wheelzandco@email');



INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (700, 'Hats and More Hats', 'BigPurpleTown 1785', 1234569871,'hatsandmorehats@email');



INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (800, 'Handmade Chairs and Seating', 'BigGreyTown 8742', 1234174591,'handmadechairsandseating@email');



INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (900, 'Greenhouse Plant Growers', 'BigGreenTown 1223', 1234117891,'greenhouseplantgrowers@email');


INSERT INTO company (company_id, company_name, address, phone_number,  email)

VALUES (000, 'Software Hardware', 'SmallBrownTown 1885', 1234117891,'softwarehardware@email');
