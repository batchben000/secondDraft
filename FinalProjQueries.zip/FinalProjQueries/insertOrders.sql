INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (000, '001', 3,'02-12-23',03);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (100, '002', 5,'01-14-23',4);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (200, '003', 13,'01-23-23',10);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (300, '004', 1,'12-12-23',11);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (400, '005', 11,'04-15-23',25);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (500, '006', 1,'02-28-23',31);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (600, '007', 3,'02-12-23',43);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (700, '008', 10,'02-12-23',55);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (800, '009', 12,'05-12-23',61);



INSERT INTO orders (company_id, order_id, quantity, order_date, product_id)

VALUES (900, '010', 5,'10-12-23',72);