DELETE FROM product
WHERE product_id = xx;
