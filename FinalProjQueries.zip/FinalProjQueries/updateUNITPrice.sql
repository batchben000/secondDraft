UPDATE product
SET unit_price = 22.99
WHERE product_id = 1;