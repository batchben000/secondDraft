SELECT p.product_id, p.product_name, p.unit_price
FROM product p
JOIN company c ON p.company_id = c.company_id
WHERE c.company_name = 'T-Biz';
