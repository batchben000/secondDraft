SELECT * FROM company

SELECT * FROM inventory

SELECT * FROm product

SELECT * FROM orders