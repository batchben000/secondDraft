INSERT INTO inventory (inventory_id, quantity, product_name)
SELECT product_id, 10, product_name
FROM product
WHERE product_id NOT IN (SELECT inventory_id FROM inventory);

