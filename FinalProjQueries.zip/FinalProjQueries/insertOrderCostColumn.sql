ALTER TABLE orders
ADD order_cost INT

ALTER TABLE orders
DROP COLUMN order_cost