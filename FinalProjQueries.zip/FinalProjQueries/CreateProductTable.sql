CREATE TABLE product (
  product_id INT PRIMARY KEY,
  product_name VARCHAR(50),
  unit_price DECIMAL(10, 2),
  description TEXT,
  company_id INT,
  FOREIGN KEY (company_id) REFERENCES company(company_id)
);
