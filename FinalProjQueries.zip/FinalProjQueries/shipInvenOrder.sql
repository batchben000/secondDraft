CREATE TABLE inventory (
   inventory_id INT PRIMARY KEY,
   product_id INT,
   quantity INT,
   FOREIGN KEY (product_id) REFERENCES product(product_id)
);


CREATE TABLE shipment (
   shipment_id INT PRIMARY KEY,
   product_id INT,
   quantity INT,
   shipment_date DATE,
   company_id INT,
   FOREIGN KEY (product_id) REFERENCES product(product_id),
   FOREIGN KEY (company_id) REFERENCES company(company_id)
);

CREATE TABLE orders (
   order_id INT PRIMARY KEY,
   product_id INT,
   quantity INT,
   order_date DATE,
   company_id INT,
   FOREIGN KEY (product_id) REFERENCES product(product_id),
   FOREIGN KEY (company_id) REFERENCES company(company_id)
);